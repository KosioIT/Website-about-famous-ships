var caption = document.getElementsByClassName("caption");

$(document).ready(function() {
    $('img').hover(function() {
        $(caption).css("display", "none");
    }, function() {
        $(caption).css("display", "block");
    });
});