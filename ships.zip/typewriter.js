var i = 0;
var speed = 49;
var txt = 'Здравейте! В този сайт ще намерите рисунки на известни и красиви кораби, с чието изобретяване са се осъществили важни промени в корабостроенето, а също и в начините на транспорт. Освен това ще можете да прочетете малко информация за тях. Надяваме се да ви хареса! 😊';
window.onload = function typeWriter() {
    if (i < txt.length) {
        document.getElementById("typeP").style.fontSize = "26px";
        document.getElementById("typeP").style.marginLeft = "4px";
        document.getElementById("typeP").style.textAlign = "justify";
        document.getElementById("typeP").style.fontFamily = "Garamond, 'Times New Roman', serif";
        document.getElementById("typeP").innerHTML += txt.charAt(i);
        i++;
        setTimeout(typeWriter, speed);
    }
}
typeWriter()