function backToHomePage() {
    window.open("shipsDrawings.html", "_self");
}