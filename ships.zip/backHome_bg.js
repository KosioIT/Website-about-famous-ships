function backToHomePage() {
    window.open("strangeCats_bg.html", "_self");
}