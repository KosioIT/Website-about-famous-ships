function backToHomePage() {
    window.open("shipsDrwaings-en.html", "_self");
}