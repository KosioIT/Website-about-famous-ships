$("#psSld").click(function() {
    $("article").toggleClass("paused")
});