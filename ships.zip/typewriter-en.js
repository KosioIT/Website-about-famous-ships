var i = 0;
var speed = 49;
var txt = 'Hello! In this site you will find drawings of famous and beautiful ships, with the invention of which important changes were made in shipbuilding, as well as in the modes of transport. You will also be able to read some information about them. We hope you like it! 😊';
window.onload = function typeWriter() {
    if (i < txt.length) {
        document.getElementById("typeP").style.fontSize = "26px";
        document.getElementById("typeP").style.marginLeft = "4px";
        document.getElementById("typeP").style.textAlign = "justify";
        document.getElementById("typeP").style.fontFamily = "Garamond, 'Times New Roman', serif";
        document.getElementById("typeP").innerHTML += txt.charAt(i);
        i++;
        setTimeout(typeWriter, speed);
    }
}
typeWriter()