var caption = document.getElementsByClassName("caption");
var tetonic = document.getElementById("tetonic");
var tncImg = document.getElementById("tnc");

window.onload = function hideCaptions() {
    caption.css("display", "none");
}
hideCaptions();

$(document).ready(function() {
    tncImg.hover(function() {
        tetonic.css("display", "block");
    }, function() {
        tetonic.css("display", "none");
    });
})